// import axios from 'axios';

// const api = axios.create({
//   baseURL: 'https://localhost:5002', // Replace with your backend URL
//   timeout: 10000, // Request timeout in ms
// });

// export default api;
